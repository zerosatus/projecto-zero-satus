package com.example.zero.database

import androidx.room.*
import com.example.zero.models.CalendarEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM events WHERE userId = :userId ORDER BY date ASC")
    fun getAllEvents(userId: String): Flow<List<CalendarEvent>>

    @Query("SELECT * FROM events WHERE userId = :userId AND date = :date")
    suspend fun getEventsByDate(userId: String, date: String): List<CalendarEvent>

    @Insert
    suspend fun insertEvent(event: CalendarEvent)

    @Update
    suspend fun updateEvent(event: CalendarEvent)

    @Delete
    suspend fun deleteEvent(event: CalendarEvent)

    @Query("DELETE FROM events WHERE userId = :userId")
    suspend fun deleteAllEvents(userId: String)
}