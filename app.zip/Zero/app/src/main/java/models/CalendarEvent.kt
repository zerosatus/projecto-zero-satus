package com.example.zero.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "events")
data class CalendarEvent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val date: String,
    val start: String,
    val end: String,
    val type: String = "outro", // aula, prova, tarefa, outro
    val color: String = "#8b5cf6",
    val userId: String = ""
)