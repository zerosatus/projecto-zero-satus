package com.example.zero.models

data class User(
    val uid: String = "",
    val nome: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val logado: Boolean = true
)