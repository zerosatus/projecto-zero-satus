package com.example.zero.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subject: String,
    val date: String,
    val priority: String = "media", // baixa, media, alta
    val color: String = "#6366f1",
    val completed: Boolean = false,
    val userId: String = ""
)