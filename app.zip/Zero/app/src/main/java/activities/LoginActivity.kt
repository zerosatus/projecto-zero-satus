package com.example.zero.activities

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.zero.databinding.ActivityLoginBinding
import com.example.zero.utils.FirebaseHelper
import com.example.zero.utils.PreferencesManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var firebaseHelper: FirebaseHelper
    private lateinit var prefs: PreferencesManager
    private var isLoginMode = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseHelper = FirebaseHelper(this)
        prefs = PreferencesManager(this)

        setupTabs()
        setupButtons()
    }

    private fun setupTabs() {
        binding.tabLogin.setOnClickListener {
            isLoginMode = true
            binding.tabLogin.isSelected = true
            binding.tabRegister.isSelected = false
            binding.registerForm.visibility = View.GONE
            binding.loginForm.visibility = View.VISIBLE
            binding.btnAction.text = "ENTRAR"
        }

        binding.tabRegister.setOnClickListener {
            isLoginMode = false
            binding.tabRegister.isSelected = true
            binding.tabLogin.isSelected = false
            binding.loginForm.visibility = View.GONE
            binding.registerForm.visibility = View.VISIBLE
            binding.btnAction.text = "CRIAR CONTA"
        }
    }

    private fun setupButtons() {
        binding.btnAction.setOnClickListener {
            if (isLoginMode) {
                performLogin()
            } else {
                performRegister()
            }
        }

        binding.forgotPassword.setOnClickListener {
            val email = binding.loginEmail.text.toString()
            if (email.isNotEmpty()) {
                // Implement password reset
                Toast.makeText(this, "Link de recuperação enviado para $email", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Digite seu e-mail primeiro", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun performLogin() {
        val email = binding.loginEmail.text.toString().trim()
        val password = binding.loginPassword.text.toString()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnAction.isEnabled = false

        lifecycleScope.launch {
            val result = firebaseHelper.login(email, password)
            binding.progressBar.visibility = View.GONE
            binding.btnAction.isEnabled = true

            if (result.isSuccess) {
                val user = result.getOrNull()!!
                prefs.saveUser(user.uid, user.nome, user.email)
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this@LoginActivity, "Erro: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun performRegister() {
        val nome = binding.registerNome.text.toString().trim()
        val email = binding.registerEmail.text.toString().trim()
        val password = binding.registerPassword.text.toString()

        if (nome.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(this, "Senha deve ter pelo menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnAction.isEnabled = false

        lifecycleScope.launch {
            val result = firebaseHelper.register(nome, email, password)
            binding.progressBar.visibility = View.GONE
            binding.btnAction.isEnabled = true

            if (result.isSuccess) {
                Toast.makeText(this@LoginActivity, "Conta criada com sucesso! Faça login.", Toast.LENGTH_LONG).show()
                // Switch to login mode
                binding.tabLogin.performClick()
                binding.loginEmail.setText(email)
            } else {
                Toast.makeText(this@LoginActivity, "Erro: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}