package com.example.zero.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.zero.R
import com.example.zero.adapters.NotesAdapter
import com.example.zero.database.AppDatabase
import com.example.zero.databinding.FragmentNotesBinding
import com.example.zero.models.Note
import com.example.zero.utils.PreferencesManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class NotesFragment : Fragment() {
    private var _binding: FragmentNotesBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager
    private lateinit var notesAdapter: NotesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())

        setupRecyclerView()
        setupFab()
        loadNotes()
    }

    private fun setupRecyclerView() {
        notesAdapter = NotesAdapter(
            onItemClick = { note -> showNoteDialog(note) },
            onDeleteClick = { note -> deleteNote(note) }
        )
        binding.recyclerNotes.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerNotes.adapter = notesAdapter
    }

    private fun loadNotes() {
        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(requireContext())
            db.noteDao().getAllNotes(prefs.getUserUid()).collect { notes ->
                notesAdapter.submitList(notes)
            }
        }
    }

    private fun setupFab() {
        binding.fabAddNote.setOnClickListener {
            showNoteDialog(null)
        }
    }

    private fun showNoteDialog(note: Note?) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_note, null)
        val titleInput = dialogView.findViewById<EditText>(R.id.editNoteTitle)
        val contentInput = dialogView.findViewById<EditText>(R.id.editNoteContent)

        if (note != null) {
            titleInput.setText(note.title)
            contentInput.setText(note.content)
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle(if (note == null) "Nova Anotação" else "Editar Anotação")
            .setView(dialogView)
            .setPositiveButton("Salvar") { _, _ ->
                val title = titleInput.text.toString().trim()
                val content = contentInput.text.toString().trim()

                if (title.isNotEmpty() || content.isNotEmpty()) {
                    lifecycleScope.launch {
                        val db = AppDatabase.getDatabase(requireContext())
                        if (note == null) {
                            db.noteDao().insertNote(
                                Note(
                                    title = title.ifEmpty { "Sem título" },
                                    content = content,
                                    userId = prefs.getUserUid()
                                )
                            )
                        } else {
                            db.noteDao().updateNote(
                                note.copy(
                                    title = title.ifEmpty { note.title },
                                    content = content
                                )
                            )
                        }
                        loadNotes()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()
    }

    private fun deleteNote(note: Note) {
        AlertDialog.Builder(requireContext())
            .setTitle("Excluir Anotação")
            .setMessage("Tem certeza que deseja excluir esta anotação?")
            .setPositiveButton("Excluir") { _, _ ->
                lifecycleScope.launch {
                    AppDatabase.getDatabase(requireContext()).noteDao().deleteNote(note)
                    loadNotes()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}