package com.example.zero.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.zero.R
import com.example.zero.adapters.TasksAdapter
import com.example.zero.database.AppDatabase
import com.example.zero.databinding.FragmentTasksBinding
import com.example.zero.models.Task
import com.example.zero.utils.PreferencesManager
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class TasksFragment : Fragment() {
    private var _binding: FragmentTasksBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager
    private lateinit var tasksAdapter: TasksAdapter
    private var currentFilter = "todos"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTasksBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())

        setupRecyclerView()
        setupFilters()
        setupFab()
        loadTasks()
    }

    private fun setupRecyclerView() {
        tasksAdapter = TasksAdapter { task ->
            toggleTaskCompletion(task)
        }
        binding.recyclerTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerTasks.adapter = tasksAdapter
    }

    private fun setupFilters() {
        binding.chipTodos.setOnClickListener {
            currentFilter = "todos"
            updateChipSelection(binding.chipTodos)
            loadTasks()
        }
        binding.chipPendentes.setOnClickListener {
            currentFilter = "pendentes"
            updateChipSelection(binding.chipPendentes)
            loadTasks()
        }
        binding.chipConcluidas.setOnClickListener {
            currentFilter = "concluidas"
            updateChipSelection(binding.chipConcluidas)
            loadTasks()
        }
    }

    private fun updateChipSelection(selectedChip: Chip) {
        listOf(binding.chipTodos, binding.chipPendentes, binding.chipConcluidas).forEach { chip ->
            chip.isChecked = chip == selectedChip
        }
    }

    private fun loadTasks() {
        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(requireContext())
            db.taskDao().getAllTasks(prefs.getUserUid()).collect { allTasks ->
                val filtered = when (currentFilter) {
                    "pendentes" -> allTasks.filter { !it.completed }
                    "concluidas" -> allTasks.filter { it.completed }
                    else -> allTasks
                }
                tasksAdapter.submitList(filtered.sortedByDescending { it.date })
            }
        }
    }

    private fun toggleTaskCompletion(task: Task) {
        lifecycleScope.launch {
            val updatedTask = task.copy(completed = !task.completed)
            AppDatabase.getDatabase(requireContext()).taskDao().updateTask(updatedTask)
        }
    }

    private fun setupFab() {
        binding.fabAddTask.setOnClickListener {
            showTaskDialog(null)
        }
    }

    private fun showTaskDialog(task: Task?) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_task, null)
        val titleInput = dialogView.findViewById<EditText>(R.id.editTaskTitle)
        val subjectInput = dialogView.findViewById<EditText>(R.id.editTaskSubject)
        val dateInput = dialogView.findViewById<EditText>(R.id.editTaskDate)
        val prioritySpinner = dialogView.findViewById<Spinner>(R.id.spinnerPriority)
        val colorPicker = dialogView.findViewById<View>(R.id.colorPicker)

        if (task != null) {
            titleInput.setText(task.title)
            subjectInput.setText(task.subject)
            dateInput.setText(task.date)
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle(if (task == null) "Nova Tarefa" else "Editar Tarefa")
            .setView(dialogView)
            .setPositiveButton("Salvar") { _, _ ->
                val title = titleInput.text.toString().trim()
                val subject = subjectInput.text.toString().trim()
                val date = dateInput.text.toString().trim()

                if (title.isNotEmpty()) {
                    lifecycleScope.launch {
                        val db = AppDatabase.getDatabase(requireContext())
                        if (task == null) {
                            db.taskDao().insertTask(
                                Task(
                                    title = title,
                                    subject = subject.ifEmpty { "Geral" },
                                    date = date.ifEmpty { "Hoje" },
                                    userId = prefs.getUserUid()
                                )
                            )
                        } else {
                            db.taskDao().updateTask(
                                task.copy(
                                    title = title,
                                    subject = subject.ifEmpty { task.subject },
                                    date = date.ifEmpty { task.date }
                                )
                            )
                        }
                        loadTasks()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}