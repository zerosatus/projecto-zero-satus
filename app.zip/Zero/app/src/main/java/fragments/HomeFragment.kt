package com.example.zero.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.zero.R
import com.example.zero.adapters.TasksAdapter
import com.example.zero.database.AppDatabase
import com.example.zero.databinding.FragmentHomeBinding
import com.example.zero.models.Task
import com.example.zero.utils.PreferencesManager
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager
    private lateinit var tasksAdapter: TasksAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())

        setupRecyclerView()
        loadUserData()
        loadTasks()
    }

    private fun setupRecyclerView() {
        tasksAdapter = TasksAdapter { task ->
            toggleTaskCompletion(task)
        }
        binding.recyclerPendingTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerPendingTasks.adapter = tasksAdapter
    }

    private fun loadUserData() {
        binding.textUserName.text = prefs.getUserNome().split(" ")[0]
    }

    private fun loadTasks() {
        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(requireContext())
            db.taskDao().getPendingTasks(prefs.getUserUid()).collect { tasks ->
                tasksAdapter.submitList(tasks.take(3))
                updateStats(tasks)
            }
        }
    }

    private fun updateStats(tasks: List<Task>) {
        val total = tasks.size
        val completed = tasks.count { it.completed }
        val pending = total - completed

        binding.textTotalTasks.text = total.toString()
        binding.textCompletedTasks.text = completed.toString()
        binding.textPendingTasks.text = pending.toString()
    }

    private fun toggleTaskCompletion(task: Task) {
        lifecycleScope.launch {
            val updatedTask = task.copy(completed = !task.completed)
            AppDatabase.getDatabase(requireContext()).taskDao().updateTask(updatedTask)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}