package com.example.zero.utils

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("zero_prefs", Context.MODE_PRIVATE)

    fun saveUser(uid: String, nome: String, email: String) {
        prefs.edit().apply {
            putString("user_uid", uid)
            putString("user_nome", nome)
            putString("user_email", email)
            putBoolean("is_logged_in", true)
            apply()
        }
    }

    fun getUserUid(): String = prefs.getString("user_uid", "") ?: ""
    fun getUserNome(): String = prefs.getString("user_nome", "Usuário") ?: "Usuário"
    fun getUserEmail(): String = prefs.getString("user_email", "") ?: ""
    fun isLoggedIn(): Boolean = prefs.getBoolean("is_logged_in", false)

    fun clearUser() {
        prefs.edit().clear().apply()
    }
}