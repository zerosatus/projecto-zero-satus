package com.example.zero.utils

import android.content.Context
import com.example.zero.models.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class FirebaseHelper(private val context: Context) {
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    suspend fun login(email: String, password: String): Result<User> {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            val user = User(
                uid = result.user?.uid ?: "",
                nome = result.user?.displayName ?: email.split("@")[0],
                email = email
            )
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun register(nome: String, email: String, password: String): Result<User> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            result.user?.updateProfile(com.google.firebase.auth.UserProfileChangeRequest.Builder()
                .setDisplayName(nome)
                .build())?.await()
            
            val user = User(
                uid = result.user?.uid ?: "",
                nome = nome,
                email = email
            )
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun syncTasksToCloud(userId: String, tasks: List<Task>) {
        try {
            val batch = firestore.batch()
            tasks.forEach { task ->
                val docRef = firestore.collection("users").document(userId)
                    .collection("tasks").document(task.id.toString())
                batch.set(docRef, task)
            }
            batch.commit().await()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun syncNotesToCloud(userId: String, notes: List<Note>) {
        try {
            val batch = firestore.batch()
            notes.forEach { note ->
                val docRef = firestore.collection("users").document(userId)
                    .collection("notes").document(note.id.toString())
                batch.set(docRef, note)
            }
            batch.commit().await()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun logout() {
        auth.signOut()
    }
}