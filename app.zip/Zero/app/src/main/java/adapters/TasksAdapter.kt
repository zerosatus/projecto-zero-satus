package com.example.zero.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.zero.databinding.ItemTaskBinding
import com.example.zero.models.Task
import java.text.SimpleDateFormat
import java.util.*

class TasksAdapter(
    private val onTaskClick: (Task) -> Unit
) : ListAdapter<Task, TasksAdapter.TaskViewHolder>(TaskDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding, onTaskClick)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class TaskViewHolder(
        private val binding: ItemTaskBinding,
        private val onTaskClick: (Task) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(task: Task) {
            binding.textTitle.text = task.title
            binding.textSubject.text = task.subject
            binding.textDate.text = task.date

            val priorityColor = when (task.priority) {
                "alta" -> "#EF4444"
                "baixa" -> "#10B981"
                else -> "#F59E0B"
            }
            binding.viewPriority.setBackgroundColor(android.graphics.Color.parseColor(priorityColor))

            binding.checkCompleted.isChecked = task.completed
            binding.checkCompleted.setOnCheckedChangeListener { _, isChecked ->
                onTaskClick(task.copy(completed = isChecked))
            }

            binding.root.setOnClickListener {
                onTaskClick(task)
            }
        }
    }
}

class TaskDiffCallback : DiffUtil.ItemCallback<Task>() {
    override fun areItemsTheSame(oldItem: Task, newItem: Task): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: Task, newItem: Task): Boolean = oldItem == newItem
}